package controller.attributes;


import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Paths;

import model.DAO.UpdateDAO;

/**
 * Servlet implementation class AddProduct
 */
@MultipartConfig()
public class UpdateProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id = request.getParameter("id");
		String name = request.getParameter("name");
		String brand = request.getParameter("brand");
		//String photo = request.getParameter("photo");
		String price = request.getParameter("price");
		String stock = request.getParameter("stock");
		String description = request.getParameter("description");
		String photo="";
		
		//save chsanged photo
		
				Part filePart = request.getPart("photo");
				
				if(filePart != null && filePart.getSize() > 0) {
					photo = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
					System.out.println("new phtot"+photo);
					
				   // Get the filename from the file part
		        String fileName = getFileName(filePart);
		        System.out.println("hello2");
		        // Define the directory to save the uploaded image
		        
		        
		        
		        String projectPath = "E://Assignments//assignment2//Assignment2Advanced-Programming-and-Technologies-Course-Work/";
		        String relativePath = "src/main/webapp/images/";
		        String uploadDir = projectPath + relativePath;
		        
		        
		        
		        // Create the directory if it doesn't exist
		        File uploadDirFile = new File(uploadDir);
		        System.out.println("hello4");
		        if (!uploadDirFile.exists()) {
		            uploadDirFile.mkdirs();
		        }

		        // Save the uploaded image to the specified directory
		        try (InputStream input = filePart.getInputStream();
		             OutputStream output = new FileOutputStream(new File(uploadDir + File.separator + fileName))) {

		            byte[] buffer = new byte[1024];
		            int bytesRead;
		            while ((bytesRead = input.read(buffer)) != -1) {
		                output.write(buffer, 0, bytesRead);
		            }
		        } catch (IOException e) {
		            e.printStackTrace();
		        }

		        // Optionally, you can send a response back to the client indicating the upload success
		        response.getWriter().println("Image uploaded successfully!");
		    
				}else {
					photo=request.getParameter("oldPhoto");
					System.out.println("old phtot"+photo);
				}
				
		UpdateDAO udao = new UpdateDAO();
		String message = udao.updateProduct(id, name,brand, photo, price, stock, description);
		
		
		
		if(message == "Successfully Added"){
			response.sendRedirect("product.jsp");
		}

	}
	private String getFileName(final Part part) {
	    final String partHeader = part.getHeader("content-disposition");
	    if (partHeader == null) {
	        return null; // Unable to retrieve filename, return null
	    }
	    for (String content : partHeader.split(";")) {
	        if (content.trim().startsWith("filename")) {
	            return content.substring(content.indexOf('=') + 1).trim().replace("\"", "");
	        }
	    }
	    return null; // Unable to extract filename from partHeader, return null
	}


}