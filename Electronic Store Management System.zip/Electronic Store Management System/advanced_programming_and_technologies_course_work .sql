-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 08, 2024 at 06:39 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `advanced_programming_and_technologies_course_work`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `email` varchar(255) NOT NULL,
  `ProductID` varchar(255) NOT NULL,
  `CartID` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`email`, `ProductID`, `CartID`) VALUES
('admin@admin.com', '1', 11),
('nabinKhakurel@gmail.com', '1', 17),
('nabinKhakurel@gmail.com', '1', 18),
('admin@admin.com', '11', 25),
('nabinKhakurel@gmail.com', '11', 34),
('admin@admin.com', '12', 36),
('admin@admin.com', '12', 37),
('admin@admin.com', '14', 38),
('admin@admin.com', '12', 39),
('nabinKhakurel@gmail.com', '14', 42),
('nabinKhakurel@gmail.com', '19', 43),
('nabinKhakurel@gmail.com', '12', 49),
('nabinKhakurel@gmail.com', '12', 51),
('nabinKhakurel@gmail.com', '12', 52);

-- --------------------------------------------------------

--
-- Table structure for table `payment`
--

CREATE TABLE `payment` (
  `paymentmethod` varchar(255) NOT NULL,
  `cardno` varchar(255) NOT NULL,
  `expirationdate` varchar(255) NOT NULL,
  `userid` varchar(255) NOT NULL,
  `cvcno` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `ProductID` int(11) NOT NULL,
  `Name` varchar(255) NOT NULL,
  `Price` varchar(255) NOT NULL,
  `Description` varchar(255) NOT NULL,
  `Brand` varchar(255) NOT NULL,
  `ProductPhoto` varchar(255) NOT NULL,
  `Stock` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`ProductID`, `Name`, `Price`, `Description`, `Brand`, `ProductPhoto`, `Stock`) VALUES
(12, 'JBL Pulse 5 Wireless Speaker', '777.0', 'The JBL Pulse 5 Wireless Speaker is a must-have for music lovers. With its bold Pro Sound and deeper bass audio profile, it delivers an immersive listening experience', 'JBL', 'img1.jpeg', '3'),
(14, 'Houston Texans Logo Waterproof Bluetooth', '10000.0', 'Listen to your favorite tunes or podcasts while showing off your team pride with this Houston Texans Logo Waterproof Bluetooth Speaker.', 'SUPNIU', 'img3.jpeg', '1'),
(19, 'External Speaker', '777.0', 'This all-weather speaker will work with any 50 watt mobile radio and includes a 9ft cable that terminated into a 3.5 plug to plug into any radio with a 3.5 speaker jack', 'Vevavii', 'img2.jpeg', '9'),
(23, 'Speaker Kit', '90000.0', 'Add speakers to your helmet with ease using this Speaker Kit. Simply plug it into your existing wiring and install the speakers!', 'XYZ', 'img4.jpeg', '2');

-- --------------------------------------------------------

--
-- Table structure for table `purchase`
--

CREATE TABLE `purchase` (
  `CartID` varchar(255) NOT NULL,
  `Quantity` varchar(255) NOT NULL,
  `PurchaseID` int(11) NOT NULL,
  `Purchase_Date` timestamp NOT NULL DEFAULT current_timestamp(),
  `useremail` varchar(255) NOT NULL,
  `ProductID` int(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `purchase`
--

INSERT INTO `purchase` (`CartID`, `Quantity`, `PurchaseID`, `Purchase_Date`, `useremail`, `ProductID`) VALUES
('7', '1', 1, '2024-04-26 02:25:48', '', 0),
('1', '1', 2, '2024-04-26 02:25:48', '', 0),
('1', '1', 3, '2024-04-26 02:25:48', '', 0),
('8', '1', 4, '2024-04-26 02:25:48', '', 0),
('9', '1', 5, '2024-04-26 02:25:48', '', 0),
('7', '1', 6, '2024-04-26 02:28:02', '', 0),
('7', '1', 7, '2024-04-26 02:33:15', '', 0),
('10', '1', 8, '2024-04-26 02:34:49', '', 0),
('10', '1', 9, '2024-04-26 02:37:08', '', 0),
('10', '1', 10, '2024-04-26 02:38:30', '', 0),
('15', '1', 11, '2024-04-26 02:42:12', '', 0),
('16', '1', 12, '2024-04-26 02:44:04', '', 0),
('24', '1', 13, '2024-04-26 11:33:55', '', 0),
('26', '1', 14, '2024-04-28 12:35:40', '', 0),
('27', '1', 15, '2024-04-28 12:51:44', '', 0),
('28', '1', 16, '2024-04-28 15:33:44', 'nabinKhakurel@gmail.com', 0),
('29', '1', 17, '2024-04-29 10:50:15', 'nabinKhakurel@gmail.com', 12),
('30', '1', 18, '2024-04-29 10:52:00', 'nabinKhakurel@gmail.com', 11),
('31', '1', 19, '2024-04-29 10:52:01', 'nabinKhakurel@gmail.com', 11),
('33', '1', 20, '2024-04-29 12:47:18', 'nabinKhakurel@gmail.com', 10),
('35', '1', 21, '2024-05-07 11:58:49', 'admin@admin.com', 12),
('40', '1', 22, '2024-05-07 16:13:25', 'nabinKhakurel@gmail.com', 12);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `email` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `email`, `username`, `password`) VALUES
(1, 'admin@admin.com', 'sunita', 'EgmD6EhnCXMSCp2tifgx7g=='),
(2, 'nabinKhakurel@gmail.com', 'Nabin', 'EgmD6EhnCXMSCp2tifgx7g==');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`CartID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`ProductID`);

--
-- Indexes for table `purchase`
--
ALTER TABLE `purchase`
  ADD PRIMARY KEY (`PurchaseID`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `CartID` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `ProductID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `purchase`
--
ALTER TABLE `purchase`
  MODIFY `PurchaseID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
