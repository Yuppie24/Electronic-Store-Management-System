package controller.attributes;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;



import model.DAO.UpdateDAO;

/**
 * Servlet implementation class EditProfile
 */
@jakarta.servlet.annotation.WebServlet("/EditUserProfile")
public class EditUserProfile extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String id = request.getParameter("id");
		System.out.println("hhhhhhhhhh"+id);
	
				
		request.setAttribute("id", id);
	
//			response.sendRedirect("editusersprofile.jsp");
		 request.getRequestDispatcher("editusersprofile.jsp").forward(request, response);
		
	}

}
