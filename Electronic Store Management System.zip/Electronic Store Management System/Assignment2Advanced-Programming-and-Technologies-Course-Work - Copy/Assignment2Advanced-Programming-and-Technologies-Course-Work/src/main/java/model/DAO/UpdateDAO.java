package model.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import database.helper.ConnectionProvider;

public class UpdateDAO {
	public String updateProduct(String id, String name,String brand,
			 String photo, String price, String stock, String description) {
			String message = "";
			try {
				
				Connection con = ConnectionProvider.getConnection();
				String query = "UPDATE product\n"
						+ "SET Name=?,  Brand=?, ProductPhoto=?, Price=?, Stock=?, Description=?\n"
						+ "WHERE ProductID=?;";;
				PreparedStatement pst = con.prepareStatement(query);
				pst.setString(1,name);
				pst.setString(2,brand);
				pst.setString(3,photo);
				pst.setString(4,price);
				pst.setString(5,stock);
				pst.setString(6,description);
				pst.setString(7,id);
				int rows = pst.executeUpdate();
				if(rows >= 1) {
					message = "Successfully Added";
				}
				con.close();	
			} catch (SQLException | ClassNotFoundException e) {
				System.out.println(e.getMessage());
				message = e.getMessage();
			}
			return message;	
		}
	
	 public String editProfile(String id, String username) {
			String message = "";
			try {
				
				Connection con = ConnectionProvider.getConnection();
				String query = "UPDATE users\n"
						+ "SET username=?\n"
						+ "WHERE id=?;";
				PreparedStatement pst = con.prepareStatement(query);
				pst.setString(1,username);
				pst.setString(2,id);
				int rows = pst.executeUpdate();
				if(rows >= 1) {
					message = "Successfully Added";
				}
				con.close();	
			} catch (SQLException | ClassNotFoundException e) {
				System.out.println(e.getMessage());
				message = e.getMessage();
			}
			return message;	
		}
	 
}
